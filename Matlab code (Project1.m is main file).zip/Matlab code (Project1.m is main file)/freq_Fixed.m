function y=freq_Fixed(E,RATIO,i,j,V)  %fixed support

if V==0.288   
m=15.50 ;
h=0.022;
d=7829;
else
m=5.029;
h=0.020;
d=2710;
end

a1=0.30;  
format bank
C1=(E*h^3)/(12*(1-V^2));
C2=sqrt(C1/(d*h));
lamda=(pi^2/(4*a1^2))*C2*((2*i+1)^2+(2*j+1)^2*(RATIO)^2);
y=lamda/(2*pi);
end

    

