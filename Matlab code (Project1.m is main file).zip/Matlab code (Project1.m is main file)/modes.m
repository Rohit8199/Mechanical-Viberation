function [xx yy zzconst]=modes(i,j)
a1 = 1
b1 = 1;
%%%Mode shape
% m = 1;
% n = 1;
A = 1;
%%%x and y modes
x = linspace(0,a1,100);
y = linspace(0,b1,100);
[xx,yy] = meshgrid(x,y);
r = sin(i*pi*xx/a1);
s = sin(j*pi*yy/b1);
zz = r.*s;
zzconst = A*zz;
end
