function varargout = PROJECT1(varargin)
% PROJECT1 MATLAB code for PROJECT1.fig
%      PROJECT1, by itself, creates a new PROJECT1 or raises the existing
%      singleton*.
%
%      H = PROJECT1 returns the handle to a new PROJECT1 or the handle to
%      the existing singleton*.
%
%      PROJECT1('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PROJECT1.M with the given input arguments.
%
%      PROJECT1('Property','Value',...) creates a new PROJECT1 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before PROJECT1_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to PROJECT1_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help PROJECT1

% Last Modified by GUIDE v2.5 14-Aug-2023 19:39:06

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @PROJECT1_OpeningFcn, ...
                   'gui_OutputFcn',  @PROJECT1_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before PROJECT1 is made visible.
function PROJECT1_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to PROJECT1 (see VARARGIN)

% Choose default command line output for PROJECT1
handles.output = hObject;
% handles.output = hObject;
Unt=get(0,'Units');
p=get(0,'Screensize');
set(hObject,'Units',Unt);
figsize=get(hObject,'Position');
wf=figsize(3);
hf=figsize(4);ws=p(3);
hs=p(4);
pfig=[(ws-wf)/2 (hs-hf)/2 wf hf];
set(hObject,'position',pfig);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes PROJECT1 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = PROJECT1_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in listbox3.
function listbox3_Callback(hObject, eventdata, handles)
% hObject    handle to listbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox3
global i j x1
x1=get(handles.listbox3,'value');
switch(x1)
    case 2
        i=1;
        j=1;
        case 3
        i=2;
        j=1;
        case 4
        i=1;
        j=2;
        case 5
        i=2;
        j=2;
        case 6
        i=3;
        j=1;
        case 7
        i=1;
        j=3;
%         case 8
%         i=3;
%         j=3;
%     otherwise
%         errordlg('INVALID SELECTION OF MODES','ERROR','modal')
end
        

% --- Executes during object creation, after setting all properties.
function listbox3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global x y st al q a b c d e i j r xx yy
if x==1
    if c==2
        E=207*10^9;
        V=0.288;
        switch(r)
            case 2
              RATIO=1;
              frequency=freq(E,RATIO,i,j,V);
              set(handles.edit1,'string',num2str(frequency));
              axes(handles.axes1)
                 [xx yy zz]=modes(i,j);
                 mesh(xx, yy, zz);
                  colorbar;
            case 3
               RATIO=1.5;
               frequency=freq(E,RATIO,i,j,V);
               set(handles.edit1,'string',num2str(frequency));
               axes(handles.axes1)
                 [xx yy zz]=modes(i,j);
                 mesh(xx, yy, zz);
                colorbar;
            case 4
              RATIO=2.5; 
              frequency=freq(E,RATIO,i,j,V);
             set(handles.edit1,'string',num2str(frequency));
             axes(handles.axes1)
                 [xx yy zz]=modes(i,j);
                 mesh(xx, yy, zz);
                  colorbar;
          
           end 
              
     
    elseif c==3
        
        E=73.119*10^9;
        V=0.33;
        switch(r)
            case 2
              RATIO=1;
              frequency=freq(E,RATIO,i,j,V);
              set(handles.edit1,'string',num2str(frequency));
              axes(handles.axes1)
                 [xx yy zz]=modes(i,j);
                 mesh(xx, yy, zz);
                  colorbar;
            case 3
               RATIO=1.5;
               frequency=freq(E,RATIO,i,j,V);
               set(handles.edit1,'string',num2str(frequency));
               axes(handles.axes1)
                 [xx yy zz]=modes(i,j);
                 mesh(xx, yy, zz);
                  colorbar;
               
            case 4
              RATIO=2.5; 
              frequency=freq(E,RATIO,i,j,V);
             set(handles.edit1,'string',num2str(frequency));
             axes(handles.axes1)
                 [xx yy zz]=modes(i,j);
                 mesh(xx, yy, zz);
                  colorbar;
        
        
        end
        
    else
        errordlg('FIRST CHOOSE MATERIAL.','ERROR','modal');
    end
    
elseif y==1
    
    if c==2
        E=207*10^9;
        V=0.288;
        switch(r)
            case 2
              RATIO=1;
              frequency=freq_Fixed(E,RATIO,i,j,V);
              set(handles.edit1,'string',num2str(frequency));
              axes(handles.axes1)
                 [xx yy zz]=modes_fixed(i,j);
                 mesh(xx, yy, zz);
                 colorbar;
            case 3
               RATIO=1.5;
               frequency=freq_Fixed(E,RATIO,i,j,V);
               set(handles.edit1,'string',num2str(frequency));
               axes(handles.axes1)
                 [xx yy zz]=modes_fixed(i,j);
                 mesh(xx, yy, zz);
                  colorbar;
               
            case 4
              RATIO=2.5; 
              frequency=freq_Fixed(E,RATIO,i,j,V);
             set(handles.edit1,'string',num2str(frequency));
             axes(handles.axes1)
                 [xx yy zz]=modes_fixed(i,j);
                 mesh(xx, yy, zz);
                  colorbar;
           end 
              
     
    elseif c==3
        
        E=73.119*10^9;
        V=0.33;
        switch(r)
            case 2
              RATIO=1;
              frequency=freq_Fixed(E,RATIO,i,j,V);
              set(handles.edit1,'string',num2str(frequency));
              axes(handles.axes1)
                 [xx yy zz]=modes_fixed(i,j);
                 mesh(xx, yy, zz);
                  colorbar;
            case 3
               RATIO=1.5;
               frequency=freq_Fixed(E,RATIO,i,j,V);
               set(handles.edit1,'string',num2str(frequency));
               axes(handles.axes1)
                 [xx yy zz]=modes_fixed(i,j);
                 mesh(xx, yy, zz);
                  colorbar;
               
            case 4
              RATIO=2.5; 
              frequency=freq_Fixed(E,RATIO,i,j,V);
             set(handles.edit1,'string',num2str(frequency));
             axes(handles.axes1)
                 [xx yy zz]=modes_fixed(i,j);
                 mesh(xx, yy, zz);
                  colorbar;
        
        
        end
    else
        errordlg('FIRST CHOOSE MATERIAL.','ERROR','modal');
        
    end
    
else
    errordlg('FIRST CHOOSE BOUNDARY CONDITION','ERROR','modal');
    
end
   




% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton1

global q
q=get(handles.radiobutton1,'value');



% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
global  t m n
t=get(handles.slider1,'value');
% view(handles.axes1,[-37.5 t*90])
[m n]=view(handles.axes1,[-37.500 t*360]);


% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider2_Callback(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
global  t1 g n 
t1=get(handles.slider2,'value');
% view(handles.axes1,[-37.5 t*90]
view(handles.axes1,[t1*360 n]);


% --- Executes during object creation, after setting all properties.
function slider2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1
global c
c=get(handles.popupmenu1,'value');

% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu2.
function popupmenu2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2
global r
r=get(handles.popupmenu2,'value');
    

% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton2

global x y
x=get(handles.radiobutton2,'value')
y=set(handles.radiobutton3,'value',0)




% --- Executes on button press in radiobutton3.
function radiobutton3_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton3
global x y
y=get(handles.radiobutton3,'value')
x=set(handles.radiobutton2,'value',0)



% --- Executes during object creation, after setting all properties.


% --- Executes during object creation, after setting all properties.
function axes5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% imshow('C:\Users\ABHISHEK\Desktop\vibration project\iitg.jpg');
% % Hint: place code in OpeningFcn to populate axes5


% --- Executes during object creation, after setting all properties.
function axes4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% imshow('G:\IIT GUWAHATI\COURSE\VIBRATION\project\matlab code\capture1.png');
%  Hint: place code in OpeningFcn to populate axes5
% Hint: place code in OpeningFcn to populate axes4


% --- Executes on button press in radiobutton4.
function radiobutton4_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton4
global f i j m n
f=get(handles.radiobutton4,'value');
x = linspace(0,1,100);
y = linspace(0,1,100);
[xx,yy] = meshgrid(x,y);       
if f==1
    while(1)    %to stop the animation
      for t = 1:0.001:20;
           zz = 8*sin(i*pi*xx).*sin(j*pi*yy).*sin(2*pi*20*t);
            axes(handles.axes1);
           mesh(xx,yy,zz);
           axis([0 1 0 1 -8 8]);
%             view(m,n)
           pause(0.1)
           if f==0
               break      %to stop the animation
           end
           
      end
      
      break                 %to stop the animation
    end
    
else
    return
    
end


  
